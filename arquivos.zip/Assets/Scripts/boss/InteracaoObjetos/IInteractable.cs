public interface IInteractable
{
    string GetPrompt(); // n�o vamos usar agora, mas deixa pronto
    void Interact(UnityEngine.GameObject player);
}
